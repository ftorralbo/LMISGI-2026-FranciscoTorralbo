var app={};

var monCallback = function(dades){

console.log(dades);

app.oficina=dades;
var html="";
html+="<h2>Oficines</h2>"; 

app.oficina.map(office => {

html+="<div class='card'>";

html+="<div class='titulo'>"+office.city+"</div>";

html+="<div class='contenido'>";

html+="<img src='"+office.picture+"'>";

html+="<ul>";
html+="<li><b>Telèfon:</b> "+office.phone+"</li>";
html+="<li><b>Direcció:</b> "+office.addressLine1+" "+office.addressLine2+"</li>";
html+="<li><b>Estat:</b> "+office.state+"</li>";
html+="<li><b>País:</b> "+office.country+"</li>";
html+="</ul>";

html+="</div>";

html+="</div>";

});

document.getElementById("results").innerHTML=html;

}

